Author: Justin Ordonez
Class: CS 301-01
Project: 1

This project is very straightforward to run. It does not take input console arguments, 
but starting values, errorthreshold, and etc. can be easily changed in the main method if necessary. 
The method parameter inputs are as follows:
bisectionMethod(double a, double b, int nmax, double errorThreshold, int functionToUse)
 
falsePositionMethod(double a, double b, int nmax, double errorThreshold, int functionToUse)

newtonMethod(double x, int nmax, double errorThreshold, double delta, int functionToUse)

secantMethod(double a, double b, int nmax, double errorThreshold, int functionToUse)

secantMethodModified(double x, double delta, int nmax, double errorThreshold, int functionToUse)
____________________________________________________________________________________________________________
Starting value variables are a,b, and x. 

***Apologies for not creating a user input menu, but I simply ran out of time, since I did participate in hackpoly.